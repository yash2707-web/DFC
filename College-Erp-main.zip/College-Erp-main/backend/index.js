import express from "express";
import bodyParser from "body-parser";
import mongoose from "mongoose";
import cors from "cors";
import dotenv from "dotenv";

import adminRoutes from "./routes/adminRoutes.js";
import studentRoutes from "./routes/studentRoutes.js";
import facultyRoutes from "./routes/facultyRoutes.js";
import { addDummyAdmin } from "./controller/adminController.js";
import userRoutes from './routes/userRoutes.js'
import mediaRoutes from './routes/mediaRoutes.js'
import morgan from "morgan";
const app = express();
dotenv.config();
app.use(bodyParser.json({ limit: "30mb", extended: true }));
app.use(bodyParser.urlencoded({ limit: "30mb", extended: true }));
app.use(cors());

app.use("/api/admin", adminRoutes);
app.use("/api/faculty", facultyRoutes);
app.use("/api/student", studentRoutes);
app.use('/api/v1/auth', userRoutes)
app.use('/api/v1/media', mediaRoutes)
app.use(morgan('dev'))
app.use(express.static('client/build'))

const PORT = process.env.PORT || 8000;
app.get("/", (req, res) => {
  res.send("Hello to college erp API");
});


mongoose
  .connect("mongodb://localhost:27017/DFC2", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    addDummyAdmin();
    app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
  })
  .catch((error) => console.log("Mongo Error", error.message));
