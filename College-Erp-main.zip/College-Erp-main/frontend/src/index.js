import React from "react";
// import ReactDOM from "react-dom";
import "./index.css";
import App from "./App";
import { Provider } from "react-redux";
import { createStore, applyMiddleware, compose } from "redux";
import { BrowserRouter as Router } from "react-router-dom";
import reducers from "./redux/reducers";
import thunk from "redux-thunk";

const store = createStore(reducers, compose(applyMiddleware(thunk)));

// ReactDOM.render(
//   <React.StrictMode>
   
//       <Router>
//         <App />
//       </Router>
    
//   </React.StrictMode>,
//   document.getElementById("root")
// );

import ReactDOM from 'react-dom/client';

import { BrowserRouter } from 'react-router-dom'
import DataProvider from './context/DataProvider';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <Provider store={store}>
  <DataProvider>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </DataProvider>
  </Provider>
);


