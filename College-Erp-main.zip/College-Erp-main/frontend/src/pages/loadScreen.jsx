// import React, { useEffect } from 'react';
// import styled, { keyframes } from 'styled-components';
// import { motion, useAnimation } from 'framer-motion';
import { NavLink,  } from "react-router-dom"

// // Keyframes for the shining effect on the title
// const shine = keyframes`
//   0% { background-position: -500px 0; }
//   100% { background-position: 500px 0; }
// `;

// const Container = styled.div`
//   display: flex;
//   flex-direction: column;
//   align-items: center;
//   justify-content: center;
//   height: 100vh;
//   background-image: url('https://www.odysseyis.com/wp-content/uploads/2020/08/43578010_m-e1598366473976.jpg');
//   background-size: cover;
//   background-position: center;
//   text-align: center;
//   overflow: hidden;
//   padding: 20px;
// `;

// const Title = styled(motion.h1)`
//   font-size: 3rem;
//   margin-bottom: 20px;
//   color: #ffd700; /* Golden color */
//   background: linear-gradient(90deg, #ffd700, #ffffff, #ffd700);
//   background-size: 200%;
//   -webkit-background-clip: text;
//   -webkit-text-fill-color: transparent;
//   animation: ${shine} 2s infinite linear;
// `;

// const BoxesContainer = styled.div`
//   display: flex;
//   justify-content: space-around;
//   width: 80%;
//   max-width: 1200px;
//   margin: 20px 0;
// `;

// const Box = styled(motion.div)`
//   background: rgba(255, 255, 255, 0.8);
//   border-radius: 10px;
//   box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
//   padding: 20px;
//   width: 45%;
//   min-width: 250px;
//   transition: transform 0.3s;
//   &:hover {
//     transform: scale(1.05);
//   }
// `;

// const Button = styled(motion.button)`
//   background: #007bff;
//   color: white;
//   border: none;
//   border-radius: 5px;
//   padding: 10px 20px;
//   cursor: pointer;
//   font-size: 1rem;
//   transition: background 0.3s;
//   &:hover {
//     background: #0056b3;
//   }
// `;

// const Paragraph = styled.p`
//   font-size: 1rem;
//   color: #555;
//   line-height: 1.5;
//   margin-top: 10px;
// `;

// const BackgroundParagraphs = styled.div`
//   position: absolute;
//   top: -20%;
//   left: -20%;
//   width: 140%;
//   height: 140%;
//   display: flex;
//   flex-wrap: wrap;
//   pointer-events: none;
// `;

const backgroundAnimation = keyframes`
  0% { transform: translateY(0); }
  50% { transform: translateY(-10px); }
  100% { transform: translateY(0); }
`;

// const AnimatedParagraph = styled(motion.p)`
//   font-size: 1.5rem;
//   color: rgba(0, 0, 0, 0.05);
//   animation: ${backgroundAnimation} 5s infinite;
//   margin: 20px;
//   width: 100%;
//   text-align: center;
// `;

// const LoadScreen = () => {
//   const controls = useAnimation();

//   useEffect(() => {
//     controls.start({
//       opacity: [0, 1],
//       transition: { duration: 2 },
//     });
//   }, [controls]);

//   return (
//     <Container>
//       <Title animate={controls}>Welcome to Digital Filing Cabinet</Title>
//       <BoxesContainer>
//         <Box whileHover={{ scale: 1.05 }} animate={controls}>
//           <h2>Box 1</h2>
//           <Paragraph>This is some content inside the first box.</Paragraph>
//           <Button whileHover={{ scale: 1.1 }} animate={controls} >
//             <NavLink to="/public">
//             Click Me</NavLink>
        
//           </Button>
//         </Box>
//         <Box whileHover={{ scale: 1.05 }} animate={controls}>
//           <h2>Box 2</h2>
//           <Paragraph>This is some content inside the second box.</Paragraph>
//           <Button whileHover={{ scale: 1.1 }} animate={controls}>
//             Click Me
//           </Button>
//         </Box>
//       </BoxesContainer>
//       <BackgroundParagraphs>
//         <AnimatedParagraph animate={controls}>Hover Effects</AnimatedParagraph>
//         <AnimatedParagraph animate={controls}>Responsive Design</AnimatedParagraph>
//         <AnimatedParagraph animate={controls}>Beautiful Animations</AnimatedParagraph>
//         <AnimatedParagraph animate={controls}>Styled Components</AnimatedParagraph>
//         <AnimatedParagraph animate={controls}>Framer Motion</AnimatedParagraph>
//       </BackgroundParagraphs>
//     </Container>
//   );
// };



// export default LoadScreen;
import React, { useEffect } from 'react';
import styled, { keyframes } from 'styled-components';
import { motion, useAnimation } from 'framer-motion';

// Keyframes for the shining effect on the title
const shine = keyframes`
  0% { background-position: -500px 0; }
  100% { background-position: 500px 0; }
`;

// Keyframes for the bounce effect
const bounce = keyframes`
  0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
  40% { transform: translateY(-30px); }
  60% { transform: translateY(-15px); }
`;

const Container = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100vh;
  background-image: url('https://www.odysseyis.com/wp-content/uploads/2020/08/43578010_m-e1598366473976.jpg');
  background-size: cover;
  background-position: center;
  text-align: center;
  overflow: hidden;
  padding: 20px;
`;

const Title = styled(motion.h1)`
  font-size: 3rem;
  margin-bottom: 20px;
  color: #b8860b; /* Darker gold color */
  background: linear-gradient(90deg, #b8860b, #ffffff, #b8860b);
  background-size: 200%;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  animation: ${shine} 2s infinite linear, ${bounce} 5s ease-in-out;
  font-weight: bold;
   text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.1); /* Text shadow */
`;

const BoxesContainer = styled.div`
  display: flex;
  justify-content: space-around;
  width: 80%;
  max-width: 1200px;
  margin: 20px 0;
`;

const Box = styled(motion.div)`
  background: rgba(255, 255, 255, 0.8);
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  padding: 20px;
  width: 45%;
  min-width: 250px;
  transition: transform 0.3s;
  &:hover {
    transform: scale(1.05);
  }
  animation: ${bounce} 5s ease-in-out;
`;

const Button = styled(motion.button)`
  background: #007bff;
  color: white;
  border: none;
  border-radius: 5px;
  padding: 10px 20px;
  cursor: pointer;
  font-size: 1rem;
  transition: background 0.3s;
  &:hover {
    background: #0056b3;
  }
  animation: ${bounce} 5s ease-in-out;
`;

const Paragraph = styled(motion.p)`
  font-size: 1rem;
  color: #555;
  line-height: 1.5;
  margin-top: 10px;
  animation: ${bounce} 5s ease-in-out;
`;

const BackgroundParagraphs = styled.div`
  position: absolute;
  top: -20%;
  left: -20%;
  width: 140%;
  height: 140%;
  display: flex;
  flex-wrap: wrap;
  pointer-events: none;
`;

const AnimatedParagraph = styled(motion.p)`
  font-size: 1.5rem;
  color: rgba(0, 0, 0, 0.05);
  animation: ${bounce} 5s ease-in-out, ${backgroundAnimation} 5s infinite;
  margin: 20px;
  width: 100%;
  text-align: center;
`;

const LoadScreen = () => {
  const controls = useAnimation();

  useEffect(() => {
    controls.start({
      opacity: [0, 1],
      transition: { duration: 2 },
    });
  }, [controls]);

  return (
    <Container>
      <Title animate={controls}>Welcome to Digital Filing Cabinet</Title>
      <BoxesContainer style={{fontWeight:"bold",fontFamily: 'Roboto, sans-serif'}}>
        <Box whileHover={{ scale: 1.05 }} animate={controls}>
          <h1 style={{fontSize:"30px"}}>Community Version</h1>
          <Paragraph>Discover the power of organization with our free Community Edition of the Digital Filing Cabinet. Perfect for personal use, small teams, or community projects, this version offers essential features to manage and store your documents securely.Robust security measures  to protect sensitive data.</Paragraph>
          <Button whileHover={{ scale: 1.1 }} animate={controls} style={{marginTop:"10px"}}>
          <NavLink to="/public">
            Explore
            </NavLink>
          </Button>
        </Box>
        <Box whileHover={{ scale: 1.05 }} animate={controls}>
          <h1 style={{fontSize:"30px"}}>Enterprise Version</h1>
          <Paragraph>Take your document management to the next level with the Enterprise Edition of the Digital Filing Cabinet. Designed for businesses and organizations of all sizes, this version offers advanced features and scalability to meet your organization's needs.</Paragraph>
          <Button whileHover={{ scale: 1.1 }} animate={controls} style={{marginTop:"10px"}}>
          <NavLink to="/enterprise">
            Explore
            </NavLink>
          </Button>
        </Box>
      </BoxesContainer>
      <BackgroundParagraphs>
        <AnimatedParagraph animate={controls}>Hover Effects</AnimatedParagraph>
        <AnimatedParagraph animate={controls}>Responsive Design</AnimatedParagraph>
        <AnimatedParagraph animate={controls}>Beautiful Animations</AnimatedParagraph>
        <AnimatedParagraph animate={controls}>Styled Components</AnimatedParagraph>
        <AnimatedParagraph animate={controls}>Framer Motion</AnimatedParagraph>
      </BackgroundParagraphs>
    </Container>
  );
};

export default LoadScreen;
